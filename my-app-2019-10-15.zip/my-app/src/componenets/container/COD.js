import React, { Component } from 'react'
import Table from '../presentational/table/Table';
import Card from '../presentational/card/Card';
import Api from '../../config/Api';

export default class COD extends Component {

    constructor(props) {
        super(props);
        this.state = {
            date: '1398-07-14',
            data: {
                "1398-07-14": {
                    "کارتخوان-سرویس پرداخت": {
                        "codAmountSum": 15000000,
                        "shipments": [
                            {
                                "waybillNumber": "10118701282285",
                                "reference": "85477",
                                "codAmount": 15000000,
                                "codPaymentReferenceInfo": "121554878787"
                            },
                            {
                                "waybillNumber": "154987632",
                                "reference": "98987",
                                "codAmount": 2500000,
                                "codPaymentReferenceInfo": "121217878"
                            },
                            {
                                "waybillNumber": "10118701282285",
                                "reference": "55887",
                                "codAmount": 1250000,
                                "codPaymentReferenceInfo": "1250000"
                            }
                        ]
                    },
                    "نقد": {
                        "codAmountSum": 25000000,
                        "shipments": [
                            {
                                "waybillNumber": "10118701282285",
                                "reference": "85477",
                                "codAmount": 15000000,
                                "codPaymentReferenceInfo": "121554878787"
                            },
                            {
                                "waybillNumber": "154987632",
                                "reference": "98987",
                                "codAmount": 2500000,
                                "codPaymentReferenceInfo": "121217878"
                            },
                            {
                                "waybillNumber": "10118701282285",
                                "reference": "55887",
                                "codAmount": 1250000,
                                "codPaymentReferenceInfo": "1250000"
                            }
                        ]
                    }
                },
                "1398-07-15": {
                    "کارتخوان-سرویس پرداخت": {
                        "codAmountSum": 15000000,
                        "shipments": [
                            {
                                "waybillNumber": "10118701282285",
                                "reference": "85477",
                                "codAmount": 15000000,
                                "codPaymentReferenceInfo": "121554878787"
                            },
                            {
                                "waybillNumber": "154987632",
                                "reference": "98987",
                                "codAmount": 2500000,
                                "codPaymentReferenceInfo": "121217878"
                            },
                            {
                                "waybillNumber": "10118701282285",
                                "reference": "55887",
                                "codAmount": 1250000,
                                "codPaymentReferenceInfo": "1250000"
                            }
                        ]
                    },
                    "نقد": {
                        "codAmountSum": 25000000,
                        "shipments": [
                            {
                                "waybillNumber": "10118701282285",
                                "reference": "85477",
                                "codAmount": 15000000,
                                "codPaymentReferenceInfo": "121554878787"
                            },
                            {
                                "waybillNumber": "154987632",
                                "reference": "98987",
                                "codAmount": 2500000,
                                "codPaymentReferenceInfo": "121217878"
                            },
                            {
                                "waybillNumber": "10118701282285",
                                "reference": "55887",
                                "codAmount": 1250000,
                                "codPaymentReferenceInfo": "1250000"
                            }
                        ]
                    }
                }
            }
        }

    }

    componentDidMount() {
        Api.get("/shipments/cod").then((response) => {

        })
        // var data = '{"employees":\n\
        //   [{"908887-87-7" : {"12-12-45":"John", "lastName":"Doe"}},\n\
        //    {"98764" : {"firstName":"Anna", "lastName":"Smith"}},\n\
        //    { "98762" : {"firstName":"Peter", "lastName":"Jones"}}]}';
        // var empObj = JSON.parse(data);


        // empObj.employees.forEach(function (value, index) {
        //     Object.keys(value).forEach(function (v, i) {
        //         console.log('key - ' + v + '\nvalue - ' + JSON.stringify(value[v]));
        //     });

        // })
        // var testobj = { "item": "valueItem", "item2": "valueItem2" }
        // // console.log("testItem", Object.value());
        // console.log("testItemVaue", Object.keys(testobj));
    }

    showBody(title, value) {
        let arrayBody = []
        arrayBody.push(
            <li>
                <div >{title} </div>
                <Table
                    classTable=" table-striped table-hover"
                    // classHeader="bg-inverse text-white"
                    theader={['#', "waybillNumber",
                        "codeAmount", "reference",
                        , "paymentReferenceInfo"]}

                    tbody={value.shipments}
                />
            </li>
        )
        return (
            <ul>
                {arrayBody}
            </ul>
        )

    }
    showCOD() {
        const { data } = this.state
        let array = []
        const date = ""
        let value = ""
        let method = ""
        let Naghd = ""
        let pos = ""
        let key = Object.keys(data).forEach((date, i) => {
            array.push(
                <>
                    <hr className="hrCard" />
                    <li className="COD_lable">
                        {date}
                    </li>
                </>
            )
            // date = v
            method = data[date]
            console.log("v " + date + " i " + i);
            console.log("method" + " " + JSON.stringify(method));
            Object.keys(method).forEach((KM, VM) => {

                array.push(
                    <li className="COD_body">
                        {this.showBody(KM, method[KM])}

                    </li>
                )

                console.log(method[KM], "KM" + KM + "VM" + VM);
                console.log("method[KM].shipments" + JSON.stringify(method[KM].shipments));


            })
            // console.log('key - ' + v + '\nvalue - ' + JSON.stringify(data[v]));
        })
        // method.forEach((x,y)=>{
        //     // y.shipments((item)=>{
        //     //     console.log("item",item);
        //     // })
        //     console.log("Naghd",x,y);
        // })

        console.log("object.key(gata)", value);
        return (
            <ul className="not-bullet">
                {array}
            </ul>

        )

    }

    render() {
        return (
            <Card>
                {this.showCOD()}

            </Card>
        )
    }
}
