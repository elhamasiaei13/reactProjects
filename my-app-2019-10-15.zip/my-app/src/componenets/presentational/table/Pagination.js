import React, { Component } from 'react'
import Pagination from "react-js-pagination";
import ReactPaginate from 'react-paginate';
// import "bootstrap/less/bootstrap.less";

export default class Pagination1 extends Component {
  constructor(props) {
    super(props);
    this.state = {
      activePage: 1,
      itemsCountPerPage: 2
    };
  }

  handlePageChange(pageNumber) {
    const page = pageNumber.selected + 1
     this.props.changeData(page, 2)
  }

  handleChange(pageNumber) {
    const size = this.state.itemsCountPerPage;
    this.setState({ activePage: pageNumber });
    this.props.changeData(pageNumber, size)

  }

  render() {
    // const pageCount=total 
    return (
      <div>

        <Pagination
          activePage={this.state.activePage}
          itemsCountPerPage={this.state.itemsCountPerPage}
          totalItemsCount={this.props.total}
          pageRangeDisplayed={10}
          onChange={(pageNumber) => this.handleChange(pageNumber)}
          activeClass="active"
        />

      </div>
    );
  }
}
