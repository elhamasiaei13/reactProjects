import React, { Component } from 'react'
import logo from './logo.svg';
import './App.css';
import './css/c3.min.css'
import './css/chartist.min.css'
import './css/style.min.css'
import './css/jquery-jvectormap-2.0.2.css'
import Header from './componenets/Layout/Header'
import Sider from './componenets/Layout/Sider'
import Content from './componenets/Layout/content/Content'
import Preloader from './componenets/presentational/Preloader'
import Wrapper from './componenets/presentational/Wrapper';
import Main from './componenets/container/Main'
import LoginForm from './componenets/container/LoginForm'
import Menu from './componenets/container/Menu'
import { Route, Redirect } from 'react-router-dom';
import ContainerFluid from './componenets/Layout/content/ContainerFluid';
import { UserProvider } from './componenets/container/UserProvider';


export default class App extends Component {
  // componentWillReceiveProps() {
  //   console.log("componentWillReceiveProps");
  // }
  componentWillMount() {
    if (JSON.parse(localStorage.getItem('authentication'))) {
      this.setState({ authentication: localStorage.getItem('authentication') })
    }
    else {
      this.setState({ authentication: false })

      return null
    }
  }

  constructor(props) {
    super(props);
    // this.setAuth = this.setAuth.bind(this)
    this.state = {
      authentication: true
    }
  }
  setAuth=(arg)=> {
    // console.log("arg", arg);
    this.setState({authentication:true})
  }
  render() {
    const { authentication } = this.state
    console.log("authentication",authentication);
    return (
      <>
        <Preloader />
        {!authentication && <>
        {/* <Redirect to="/login"/> */}
          <ContainerFluid >
            <LoginForm setAuth={()=>this.setAuth()}/>
          </ContainerFluid >

        </>}

        {authentication && <Wrapper>
          <Header />
          <Sider>
            <Menu />
          </Sider>
          <Content>
            <Main authentication={authentication} setAuth={()=>this.setAuth()} />
          </Content>
        </Wrapper>}
      </>
    )
  }
}
