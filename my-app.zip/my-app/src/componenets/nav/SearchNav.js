import React from 'react'

export default function SearchNav({ placeholder }) {
    return (
        <ul className="navbar-nav float-left mr-auto">
            <li className="nav-item search-box">
                <span className="nav-link waves-effect waves-dark" >
                    <div className="d-flex align-items-center">
                        <i className="mdi mdi-magnify font-20 mr-1"></i>
                        <div className="ml-1 d-none d-sm-block">
                            <span>Search</span>
                        </div>
                    </div>
                </span>
                <form className="app-search position-absolute"
                    style={{ display: 'none' }}
                >
                    <input type="text" className="form-control" placeholder="Search &amp; enter" />
                    <a className="srh-btn">
                        <i className="ti-close"></i>
                    </a>
                </form>
            </li>
        </ul>

    )
}
