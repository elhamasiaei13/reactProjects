
import * as React from 'react';
import Breadcrumb from '../breadcrumb/Breadcrumb';
export default function CardBody({
    cardTitle = false,
    cardSubtitle = false,
    body = "",
    ...props }) {

        
    return (
        <div className="card-body">
            {cardTitle ? <><h4 className="card-title text-info m-b-0">
            {cardTitle}</h4> <hr/></> : ''}
            {cardSubtitle ? <h6 className="card-subtitle">  {cardSubtitle} </h6> : ''}
            {body}
            {props.children}
        </div>
    );
}