
import React, { Component } from 'react'
import Breadcrumb from '../breadcrumb/Breadcrumb';
import CardBody from './CardBody'
import { FormattedMessage } from 'react-intl';

class Card extends Component {

    render() {

        const { body, cardTitle, cardSubtitle, cardClass } = this.props
        return (
            <div className={cardClass}>
                <CardBody
                    cardTitle={cardTitle}
                    cardSubtitle={cardSubtitle}
                >
                    {this.props.children}

                </CardBody>
            </div>
        )
    }
}
Card.defaultProps={
    cardClass:"card" ,
    cardTitle:false ,
    cardSubtitle:false 
}
export default Card
