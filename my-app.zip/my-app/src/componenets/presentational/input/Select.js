import React from 'react'
import { FormattedMessage } from 'react-intl';

//  const SetOptins = () => {
//         optins.map((item) => {
//             return (<option>{item}</option>
//             )
//         }) 

const SetOptins = (options) => {
    const head = []
    options.map((item, index) => {
        head.push(<option key={index}>{item}</option>)
    })
    return head;
}

const Select = ({
    label = "label",
    value = "",
    options = [],
    ...props }) => {

    return (
        <div className="form-group row">
            <label
                htmlFor="fname"
                className="col-sm-3 text-right control-label col-form-label"
            >
                <FormattedMessage
                    id={label}
                    defaultMessage={label}
                />
            </label>
            <div className="col-sm-9">
                <select
                    {...props}
                    className="form-control"
                    id="exampleFormControlSelect1">
                    {SetOptins(options)}
                </select>
            </div>
        </div>


    )
}
export default Select;
