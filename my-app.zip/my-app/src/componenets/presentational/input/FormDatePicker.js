
import React, { useState } from "react";
import { FormattedMessage } from "react-intl";
import moment from 'moment-jalaali'
import DatePicker from 'react-datepicker2';
moment.loadPersian({ dialect: 'persian-modern' });

// import DatePicker from 'react-datepicker-persian';
// import 'react-datepicker-persian/dist/react-datepicker-persian.min.css';

const FormDatePicker = ({
    label = "label",
    type = "text",
    placeholder = "",
    helperText = "false",
    id = "fname",
    onChange,
    ...props }) => {
    const [selectedDay, setSelectedDay] = useState(null);

    return (

        <>
            <div className="form-group row">
                <label
                    htmlFor="fname"
                    className="col-sm-3 text-right control-label col-form-label"
                >
                    <FormattedMessage
                        id={label}
                        defaultMessage={label}
                    />
                </label>

                <div className="col-sm-9">
                    <DatePicker
                        isGregorian={false}
                        //   onChange={value => this.setState({ value })}
                        value={moment()}
                    />

                    {/* <DatePicker  {...props}
                        className="form-control"
                        id={id}
                        placeholder={placeholder}
                        format="jYYYY/jMM/jDD"
                        id="datePicker"
                        // preSelected="4"
                        // onChange={onChange}
                    /> */}

                    {helperText === "false" ? '' :
                        <small
                            id="textHelp"
                            className="form-text text-muted">
                            {helperText}
                        </small>
                    }
                </div>
            </div>



        </>




    )
}
export default FormDatePicker;
