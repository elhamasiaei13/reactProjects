import React from 'react'
import { FormattedMessage } from 'react-intl';

export default function ShipperResultPartsItem({
    label = "false",
    value = "",
    ...props }) {
    return (
        <>
            {/* <div className="col-md-3 col-xs-12 "> */}
            
            <label htmlFor="fname">
                <FormattedMessage
                    id={label}
                    defaultMessage={label}
                /> :
            </label>

            <span> {value} </span>
            
            {/* </div> */}

        </>
    )
}
