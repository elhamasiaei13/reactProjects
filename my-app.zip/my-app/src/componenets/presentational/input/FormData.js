import React from 'react'
import { FormattedMessage } from 'react-intl';

const FormData = ({
    label = "false",
    value = "false",
    labelClassName = "col-sm-3",
    valueClassname = "col-md-9",
    ...props }) => {
    return (
        <div className="form-group row">
            {label !== "false" ? <label
                htmlFor="fname"
                className={"control-label  col-form-label  text-right " + labelClassName}
            >
                <FormattedMessage
                    id={label}
                    defaultMessage={label}
                />
            </label> : ''}
            {value !== "false" ?
                <div className={"col-md-9 " + valueClassname}>
                    <p className="form-control"> {value} </p>
                </div>
                : ''}

        </div>

    )
}
export default FormData;
