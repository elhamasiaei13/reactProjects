import React from 'react'
import { FormattedMessage } from 'react-intl';

export default function ViewLabel(
    { 
        value = "false",
        valueClassname = "col-md-9",
      
        ...props }) {
    return (
        <div className="form-group row">
             <label
                htmlFor="fname"
                className={"control-label col-form-label "}
            >
               {value}
            </label> 
            

        </div>

    )
} 