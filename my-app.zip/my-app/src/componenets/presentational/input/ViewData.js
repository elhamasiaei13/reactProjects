import React, { Component } from 'react'
import { FormattedMessage } from 'react-intl';

const ViewData = ({
    label = "false",
    value = false,
    labelClassName = "col-sm-3",
    ...props }) => {
    return (
        <>
            {value !== false
                ?
                <>
                    {label !== "false" ?
                        <label
                            htmlFor="fname"
                            className=" text-right control-label col-form-label"
                        >
                            <FormattedMessage
                                id={label}
                                defaultMessage={label}
                            />
                        </label> : ''}

                    <div className="col-md-3">
                        <p className="form-control"> {value} </p>
                    </div>
                </>
                :
                ''}
            {/* {label!== "false" ?  
            <label
                htmlFor="fname"
                className=" text-right control-label col-form-label"
            >
                <FormattedMessage
                    id={label}
                    defaultMessage={label}
                />
            </label> : ''}
           
            <div className="col-md-3">
                <p className="form-control"> {value} </p>
            </div> */}
        </>

    )
}
export default ViewData;

