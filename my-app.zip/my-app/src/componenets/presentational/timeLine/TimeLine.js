import React, { Component } from 'react'
import Card from '../card/Card'

class TimeLine extends Component {

    render() {
        const { title, clock, address, iconName, color } = this.props
        return (
            <>

                <li>

                    <i className={"timeline-icon" + " " + iconName + " " + color} ></i>

                    <div className=" row timeline-item-content" >

                        <div className="col-md-3 offset-md-3">
                            <strong className="timeline-item-title">{title}</strong></div>
                        <div className="col-md-4 offset-md-3 timeline-item-time">
                            {/* <div className="timeline-item"> */}
                            <i className="m-r-10 mdi mdi-clock"></i>{clock}</div>
                        {/* </div> */}
                    </div>

                    <div className="row timeline-item-content">
                        <div className="col-md-12 ">
                            <div className="timeline-item-desc">{address}</div>

                        </div>
                    </div>
                </li>
                {/* <li>
                    <div className="">
                        <i className="timeline-icon mdi mdi-home"></i>
                        <div className=" timeline-item-content" >
                            <strong className="timeline-item-title">{title}</strong>
                            <div className="timeline-item-time">{clock}</div>
                            <div className="timeline-item-desc">{address}</div>
                        </div>
                    </div>
                </li> */}
            </>
        )
    }
}
TimeLine.defaultProps = {
    title: "۹ از ۹ بسته دریافت شد",
    clock: "1398-02-05 18:52",
    address: "نمایندگی تهران-دفتر مرکزی",
    iconName: "mdi mdi-home",
    color: "lable-green"
}
export default TimeLine;