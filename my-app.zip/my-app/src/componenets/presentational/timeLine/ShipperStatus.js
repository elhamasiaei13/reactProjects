import React, { Component } from 'react'
import TimeLine from './TimeLine'
import TimeLineLabel from './TimeLineLabel'
import Card from '../card/Card'
import Row from '../Row'
import Col from '../Col';
export default class ShipperStatus extends Component {
    render() {
        return (
            <Row>
                <Col md={12} lg={12} >
                    <Card >
                        <ul className="timeline card text-black bg-light">
                            <TimeLineLabel />
                            <TimeLine
                                title="۹ از ۹ بسته دریافت شد"
                                clock="1398-02-05 18:52"
                                address="نمایندگی تهران-دفتر مرکزی"
                                iconName="mdi mdi-dna"
                                color="lable-red"
                            />
                            <TimeLine
                                title="۹ از ۹ بسته دریافت شد"
                                clock="1398-02-05 18:52"
                                address="نمایندگی تهران-دفتر مرکزی"
                                iconName="mdi mdi-arrow-up-box"
                                color="lable-green" />
                            <TimeLine
                                title="۹ از ۹ بسته دریافت شد"
                                clock="1398-02-05 18:52"
                                address="نمایندگی تهران-دفتر مرکزی"
                                iconName="mdi mdi-clock"
                                color="lable-pink" />
                            <TimeLine
                                title="۹ از ۹ بسته دریافت شد"
                                clock="1398-02-05 18:52"
                                address="نمایندگی تهران-دفتر مرکزی"
                                iconName="mdi mdi-home"
                                color="lable-orange" />
                            <TimeLineLabel />

                        </ul>
                    </Card>
                </Col>
            </Row>
        )
    }
}
