import React from 'react'
import FormInput from '../input/FormInput';
import CardBody from '../card/CardBody'

const Form = ({ formBody = '', formFooter = '',action='', ...props }) => {
    return (
        <form className="form-horizontal"  {...props} >
            <CardBody

                body={formBody
                }
            >
            </CardBody>

            <CardBody

                body={
                    <div className="form-group m-b-0 text-right">
                       {formFooter}
                    </div>
               }
            >

            </CardBody>

        </form>
    )
}
export default Form;

