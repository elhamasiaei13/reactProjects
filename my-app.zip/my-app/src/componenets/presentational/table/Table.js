import React from 'react'
import { FormattedMessage } from 'react-intl';
import { Link } from 'react-router-dom/cjs/react-router-dom.min';
import Activity from '../../presentational/Activity'
const CreateHeader = (theader) => {
    const head = []
    theader.map((item, index) => {
        head.push(<th key={item} scope="col">
            <FormattedMessage
                id={item}
                defaultMessage={item}
            />
            {/* {item} */}
        </th>)
    })
    return head;
}

const testArray = (test) => {
    test.map((item) => {
        return <td>{item}</td>
    })


}

const CreateBody = (tbody, theader) => {
    const body = [];
    tbody.map((row, index) => {
        const { First, Last, Handle } = row
        body.push(<tr key={index}>
            {theader.map((colmn, index) => {
                if (colmn == "#") { return <td key={index} scope="row">{index + 1}</td> }
                else if (colmn == "activity") {
                    return <td key={index} scope="row">
                        <Link to={"/ShipmentTracking/$" + row.waybillNumber}>
                        <i class="m-r-10 mdi mdi-pencil"></i>
                        </Link>
                    </td>
                }
                else { return <td key={index}>{row[colmn]}</td> }
            })}
        </tr>)
    })
    return body;
}


const Table = ({ theader = [], tbody = [], tableClass = "table-striped", haedClass = "", ...props }) => {
    return (
        <div className="table-responsive">
            <table className={"table  " + tableClass} {...props}>
                <thead className={haedClass}>
                    <tr>
                        {CreateHeader(theader)}
                    </tr>
                </thead>
                <tbody>
                    {CreateBody(tbody, theader)}
                </tbody>
            </table>
        </div>
    )
}
export default Table;