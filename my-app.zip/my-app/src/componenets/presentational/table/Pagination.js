import React, { Component } from 'react'

export default class Pagination extends Component {
    render() {
        return (
            <div class="card">
            {/* <div class="card-body">
                <h4 class="card-title">Static</h4>
                <div id="staticgrid" class="jsgrid" style="position: relative; height: 500px; width: 100%;">
                <div class="jsgrid-grid-header jsgrid-header-scrollbar">
                <table class="jsgrid-table table table-striped table-hover">
                <tr class="jsgrid-header-row"><th class="jsgrid-header-cell jsgrid-header-sortable" >Name</th><th class="jsgrid-header-cell jsgrid-align-right jsgrid-header-sortable" style="width: 70px;">Age</th><th class="jsgrid-header-cell jsgrid-header-sortable" style="width: 200px;">Address</th><th class="jsgrid-header-cell jsgrid-align-center jsgrid-header-sortable" style="width: 100px;">Country</th><th class="jsgrid-header-cell jsgrid-align-center jsgrid-header-sortable" style="width: 100px;">Is Married</th></tr><tr class="jsgrid-filter-row" style="display: none;"><td class="jsgrid-cell" style="width: 150px;">
                <input type="text" class="form-control input-sm"/></td>
                <td class="jsgrid-cell jsgrid-align-right" style="width: 70px;">
                <input type="number" class="form-control input-sm"/></td>
                <td class="jsgrid-cell" style="width: 200px;"><input type="text" class="form-control input-sm"/></td>
                <td class="jsgrid-cell jsgrid-align-center" style="width: 100px;"><select class="form-control input-sm">
                <option value="0"></option><option value="1">United States</option><option value="2">Canada</option>
                <option value="3">United Kingdom</option><option value="4">France</option>
                <option value="5">Brazil</option><option value="6">China</option><option value="7">Russia</option>
                </select></td><td class="jsgrid-cell jsgrid-align-center" style="width: 100px;"><input type="checkbox" readonly=""/>
                </td></tr><tr class="jsgrid-insert-row" style="display: none;"><td class="jsgrid-cell" style="width: 150px;">
                <input type="text" class="form-control input-sm"/></td><td class="jsgrid-cell jsgrid-align-right" style="width: 70px;">
                <input type="number" class="form-control input-sm"/></td><td class="jsgrid-cell" style="width: 200px;">
                <input type="text" class="form-control input-sm" /></td><td class="jsgrid-cell jsgrid-align-center" style="width: 100px;">
                <select class="form-control input-sm"><option value="0"></option><option value="1">United States</option>
                <option value="2">Canada</option><option value="3">United Kingdom</option><option value="4">France</option>
                <option value="5">Brazil</option><option value="6">China</option><option value="7">Russia</option></select>
                </td><td class="jsgrid-cell jsgrid-align-center" style="width: 100px;"><input type="checkbox"/></td></tr>
                    </table></div><div class="jsgrid-grid-body" style="height: 378px;">
                    <table class="jsgrid-table table table-striped table-hover"><tbody>
                        <tr class="jsgrid-row"><td class="jsgrid-cell" style="width: 150px;">Arthur Olsen</td>
                        <td class="jsgrid-cell jsgrid-align-right" style="width: 70px;">74</td>
                        <td class="jsgrid-cell" style="width: 200px;">887-5080 Eget St.</td>
                        <td class="jsgrid-cell jsgrid-align-center" style="width: 100px;">Brazil</td>
                        <td class="jsgrid-cell jsgrid-align-center" style="width: 100px;">
                        <input type="checkbox" disabled=""/></td></tr>
                        <tr class="jsgrid-alt-row"><td class="jsgrid-cell" style="width: 150px;">Brody Potts</td>
                        <td class="jsgrid-cell jsgrid-align-right" style="width: 70px;">59</td>
                        <td class="jsgrid-cell" style="width: 200px;">Ap #577-7690 Sem Road</td>
                        <td class="jsgrid-cell jsgrid-align-center" 
                        >Canada</td><td class="jsgrid-cell jsgrid-align-center" style="width: 100px;">
                        <input type="checkbox" disabled=""/></td></tr>
                        <tr class="jsgrid-row"><td class="jsgrid-cell" style="width: 150px;">Dillon Ford</td>
                        <td class="jsgrid-cell jsgrid-align-right" style="width: 70px;">60</td>
                        <td class="jsgrid-cell" style="width: 200px;">Ap #885-9289 A, Av.</td>
                        <td class="jsgrid-cell jsgrid-align-center" style="width: 100px;">United States</td><td class="jsgrid-cell jsgrid-align-center" style="width: 100px;"><input type="checkbox" disabled=""></td></tr><tr class="jsgrid-alt-row"><td class="jsgrid-cell" style="width: 150px;">Hannah Juarez</td><td class="jsgrid-cell jsgrid-align-right" style="width: 70px;">61</td><td class="jsgrid-cell" style="width: 200px;">4744 Sapien, Rd.</td><td class="jsgrid-cell jsgrid-align-center" style="width: 100px;">Canada</td><td class="jsgrid-cell jsgrid-align-center" style="width: 100px;"><input type="checkbox" disabled=""></td></tr><tr class="jsgrid-row"><td class="jsgrid-cell" style="width: 150px;">Vincent Shaffer</td><td class="jsgrid-cell jsgrid-align-right" style="width: 70px;">25</td><td class="jsgrid-cell" style="width: 200px;">9203 Nunc St.</td><td class="jsgrid-cell jsgrid-align-center" style="width: 100px;">Canada</td>
                        <td class="jsgrid-cell jsgrid-align-center" style="width: 100px;">
                        <input type="checkbox" disabled=""/></td></tr><tr class="jsgrid-alt-row">
                        <td class="jsgrid-cell" style="width: 150px;">George Holt</td>
                        <td class="jsgrid-cell jsgrid-align-right">27</td><td class="jsgrid-cell" >
                        4162 Cras Rd.</td><td class="jsgrid-cell jsgrid-align-center">China</td>
                        <td class="jsgrid-cell jsgrid-align-center" style="width: 100px;">
                        <input type="checkbox" disabled=""/></td></tr><tr class="jsgrid-row"><td class="jsgrid-cell"
                        >Tobias Bartlett</td><td class="jsgrid-cell jsgrid-align-right" >74</td>
                        <td class="jsgrid-cell" style="width: 200px;">792-6145 Mauris St.</td><td class="jsgrid-cell jsgrid-align-center"
                       >France</td><td class="jsgrid-cell jsgrid-align-center" style="width: 100px;">
                       <input type="checkbox" disabled=""/></td></tr><tr class="jsgrid-alt-row"><td class="jsgrid-cell"
                        >Xavier Hooper</td><td class="jsgrid-cell jsgrid-align-right" >35</td>
                        <td class="jsgrid-cell" style="width: 200px;">879-5026 Interdum. Rd.</td>
                        <td class="jsgrid-cell jsgrid-align-center" style="width: 100px;">United States</td>
                        <td class="jsgrid-cell jsgrid-align-center" style="width: 100px;">
                        <input type="checkbox" disabled=""/></td></tr>
                        <tr class="jsgrid-row"><td class="jsgrid-cell" style="width: 150px;">Declan Dorsey</td>
                        <td class="jsgrid-cell jsgrid-align-right" style="width: 70px;">31</td>
                        <td class="jsgrid-cell">Ap #926-4171 Aenean Road</td><td class="jsgrid-cell jsgrid-align-center"
                        >Canada</td><td class="jsgrid-cell jsgrid-align-center" style="width: 100px;">
                        <input type="checkbox" disabled=""/></td></tr><tr class="jsgrid-alt-row"><td class="jsgrid-cell" style="width: 150px;">Clementine Tran</td><td class="jsgrid-cell jsgrid-align-right" style="width: 70px;">43</td><td class="jsgrid-cell" style="width: 200px;">P.O. Box 176, 9865 Eu Rd.</td><td class="jsgrid-cell jsgrid-align-center" style="width: 100px;">France</td><td class="jsgrid-cell jsgrid-align-center" style="width: 100px;"><input type="checkbox" disabled=""></td></tr><tr class="jsgrid-row"><td class="jsgrid-cell" style="width: 150px;">Pamela Moody</td><td class="jsgrid-cell jsgrid-align-right" style="width: 70px;">55</td><td class="jsgrid-cell" style="width: 200px;">622-6233 Luctus Rd.</td><td class="jsgrid-cell jsgrid-align-center" style="width: 100px;">China</td><td class="jsgrid-cell jsgrid-align-center" style="width: 100px;"><input type="checkbox" disabled=""></td></tr><tr class="jsgrid-alt-row"><td class="jsgrid-cell" style="width: 150px;">Julie Leon</td><td class="jsgrid-cell jsgrid-align-right" style="width: 70px;">43</td><td class="jsgrid-cell" style="width: 200px;">Ap #915-6782 Sem Av.</td><td class="jsgrid-cell jsgrid-align-center" style="width: 100px;">China</td><td class="jsgrid-cell jsgrid-align-center" style="width: 100px;"><input type="checkbox" disabled=""></td></tr><tr class="jsgrid-row"><td class="jsgrid-cell" style="width: 150px;">Shana Nolan</td><td class="jsgrid-cell jsgrid-align-right" style="width: 70px;">79</td><td class="jsgrid-cell" style="width: 200px;">P.O. Box 603, 899 Eu St.</td><td class="jsgrid-cell jsgrid-align-center" style="width: 100px;">Brazil</td><td class="jsgrid-cell jsgrid-align-center" style="width: 100px;"><input type="checkbox" disabled=""></td></tr><tr class="jsgrid-alt-row"><td class="jsgrid-cell" style="width: 150px;">Vaughan Moody</td><td class="jsgrid-cell jsgrid-align-right" style="width: 70px;">37</td><td class="jsgrid-cell" style="width: 200px;">880 Erat Rd.</td><td class="jsgrid-cell jsgrid-align-center" style="width: 100px;">Brazil</td><td class="jsgrid-cell jsgrid-align-center" style="width: 100px;"><input type="checkbox" disabled=""></td></tr><tr class="jsgrid-row"><td class="jsgrid-cell" style="width: 150px;">Randall Reeves</td><td class="jsgrid-cell jsgrid-align-right" style="width: 70px;">44</td><td class="jsgrid-cell" style="width: 200px;">1819 Non Street</td><td class="jsgrid-cell jsgrid-align-center" style="width: 100px;">United Kingdom</td><td class="jsgrid-cell jsgrid-align-center" style="width: 100px;"><input type="checkbox" disabled=""></td></tr><tr class="jsgrid-alt-row"><td class="jsgrid-cell" style="width: 150px;">Dominic Raymond</td><td class="jsgrid-cell jsgrid-align-right" style="width: 70px;">68</td><td class="jsgrid-cell" style="width: 200px;">Ap #689-4874 Nisi Rd.</td><td class="jsgrid-cell jsgrid-align-center" style="width: 100px;">United States</td><td class="jsgrid-cell jsgrid-align-center" style="width: 100px;"><input type="checkbox" disabled=""></td></tr><tr class="jsgrid-row"><td class="jsgrid-cell" style="width: 150px;">Lev Pugh</td><td class="jsgrid-cell jsgrid-align-right" style="width: 70px;">69</td><td class="jsgrid-cell" style="width: 200px;">Ap #433-6844 Auctor Avenue</td><td class="jsgrid-cell jsgrid-align-center" style="width: 100px;">Brazil</td><td class="jsgrid-cell jsgrid-align-center" style="width: 100px;"><input type="checkbox" disabled=""></td></tr><tr class="jsgrid-alt-row"><td class="jsgrid-cell" style="width: 150px;">Desiree Hughes</td><td class="jsgrid-cell jsgrid-align-right" style="width: 70px;">80</td><td class="jsgrid-cell" style="width: 200px;">605-6645 Fermentum Avenue</td><td class="jsgrid-cell jsgrid-align-center" style="width: 100px;">France</td><td class="jsgrid-cell jsgrid-align-center" style="width: 100px;"><input type="checkbox" disabled=""></td></tr><tr class="jsgrid-row"><td class="jsgrid-cell" style="width: 150px;">Idona Oneill</td><td class="jsgrid-cell jsgrid-align-right" style="width: 70px;">23</td><td class="jsgrid-cell" style="width: 200px;">751-8148 Aliquam Avenue</td><td class="jsgrid-cell jsgrid-align-center" style="width: 100px;">Russia</td><td class="jsgrid-cell jsgrid-align-center" style="width: 100px;"><input type="checkbox" disabled=""></td></tr><tr class="jsgrid-alt-row"><td class="jsgrid-cell" style="width: 150px;">Lani Mayo</td><td class="jsgrid-cell jsgrid-align-right" style="width: 70px;">76</td><td class="jsgrid-cell" style="width: 200px;">635-2704 Tristique St.</td><td class="jsgrid-cell jsgrid-align-center" style="width: 100px;">United States</td><td class="jsgrid-cell jsgrid-align-center" style="width: 100px;"><input type="checkbox" disabled=""></td></tr></tbody></table></div><div class="jsgrid-pager-container"><div class="jsgrid-pager">Pages: <span class="jsgrid-pager-nav-button"><a href="javascript:void(0);">First</a></span> <span class="jsgrid-pager-nav-button"><a href="javascript:void(0);">Prev</a></span> <span class="jsgrid-pager-page"><a href="javascript:void(0);">1</a></span><span class="jsgrid-pager-page"><a href="javascript:void(0);">2</a></span><span class="jsgrid-pager-page"><a href="javascript:void(0);">3</a></span><span class="jsgrid-pager-page jsgrid-pager-current-page">4</span><span class="jsgrid-pager-page"><a href="javascript:void(0);">5</a></span> <span class="jsgrid-pager-nav-button"><a href="javascript:void(0);">Next</a></span> <span class="jsgrid-pager-nav-button"><a href="javascript:void(0);">Last</a></span> &nbsp;&nbsp; 4 of 5 </div></div><div class="jsgrid-load-shader" style="display: none; position: absolute; top: 0px; right: 0px; bottom: 0px; left: 0px; z-index: 1000;"></div><div class="jsgrid-load-panel" style="display: none; position: absolute; top: 50%; left: 50%; z-index: 1000;">Please, wait...</div></div>
            </div> */}
        </div>
        )
    }
}
