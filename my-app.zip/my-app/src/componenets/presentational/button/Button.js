import React, { Component } from 'react'
import { FormattedMessage } from 'react-intl';
const Button = ({ label = "", type = "", htmlType = "", onClick,...props }) => {
    return (
        <button 
        {...props}
         type={htmlType}
            onClick={onClick}
            className={"btn aves-effect waves-light btn-" + type}
        >
            <FormattedMessage
                id={label}
                defaultMessage={label}
            />
        </button>
    )
}
export default Button;