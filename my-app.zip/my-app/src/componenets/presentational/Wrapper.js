import React, { Component } from 'react'
import ContainerFluid from '../content/ContainerFluid';
import Header from '../Layout/Header';
import Sider from '../Layout/Sider';
import Content from '../../componenets/content/Content'
// import Breadcrumb from './breadcrumb/Breadcrumb';

class Wrapper extends Component {
    render() {
        const { children } = this.props
        return (
            <div id="main-wrapper"
                data-theme="dark" 
                data-layout="vertical"
                data-navbarbg="skin6"
                data-sidebartype="full"
                // data-sidebartype="mini-sidebar"
                data-sidebar-position="fixed"
                data-header-position="fixed" 
                data-boxed-layout="full"
                >

                {children}

            </div>

        )
    }
}


export default Wrapper