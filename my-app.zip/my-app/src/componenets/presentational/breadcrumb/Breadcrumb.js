import React from 'react'
import ContainerFluid from '../../content/ContainerFluid';
import { FormattedMessage } from 'react-intl';
// import PropTypes from 'prop-types';

const Breadcrumb = ({ title = "title", nav = "", ...props }) => {
    return (


        <div className="page-breadcrumb">
            <div className="row">
                <div className="col-5 align-self-center">
                    <h4 className="page-title">
                    {title}
                        {/* <FormattedMessage
                            id={title}
                            defaultMessage={title}
                        /> */}
                    </h4>
                </div>
                <div className="col-7 align-self-center">
                    <div className="d-flex align-items-center justify-content-end">
                        <nav aria-label="breadcrumb">
                            {nav}
                        </nav>
                    </div>
                </div>
            </div>
        </div>



    )

}

export default Breadcrumb