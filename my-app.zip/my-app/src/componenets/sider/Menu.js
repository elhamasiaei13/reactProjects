import React, { Component } from 'react'
import SubMenu from './SubMenu'
import MenuItem from './MenuItem'

export default class Menu extends Component {
    render() {
        // const { childeren } = this.props
        // const Showchilderen = () => { this.props.childeren ? {showItem() }: ''; }
        const array = [<MenuItem
            title={"testm"}
            href="#2"
        />]
        const arraySub=[]
        const ChildSubMenu = (item) => {
          return  <MenuItem
                title={"testm"}
                href="#2"
            />
        }
        const Showchilderen = () => {
            this.props.children.map((item) => {
                if (item.props.type === "SubMenu") {
                    array.push(
                        <SubMenu href="javascript:void(0)">
                            
                            <MenuItem
                                title={item.props.title}
                                href={item.props.href}
                            />
                            {ChildSubMenu(item)}

                        </SubMenu >
                    )
                } else if (item.props.type === "MenuItem") {
                    array.push(
                        <MenuItem
                            title={"testm"}
                            href="#2"
                        />
                    )
                }
            })
            return (array)

        }
        return (
            <aside style={{ backgroundColor: 'black' }} className="left-sidebar elham-sidebar" >
                <div className="scroll-sidebar">
                    <nav className="sidebar-nav">
                        <ul id="sidebarnav">
                            {Showchilderen()}
                            {/* <SubMenu href="javascript:void(0)">
                                <MenuItem
                                    title={"testm"}
                                    href="#1"
                                />
                                <MenuItem
                                    title={"testm"}
                                    href="#2"
                                />
                            </SubMenu > */}

                            {/*  <SubMenu title={"Dashboardm"}  href="javascript:void(0)">
                                <MenuItem
                                    title={"Classicm"}
                                    href="#3"

                                />
                                <MenuItem
                                    title={"Analyticalm"}
                                    href="#4"

                                />
                                <MenuItem
                                    title={"Modernm"}
                                    href="#5"

                                />
                                <MenuItem
                                    title={"Classicm"}
                                    href="#6"
                                />
                            </SubMenu>
                            <MenuItem
                                    title={"Modernm"}
                                    href="#112"

                                />
                                <MenuItem
                                    title={"Classicm"}
                                    href="#111"
                                /> */}
                        </ul>
                    </nav>
                </div>
            </aside>
        )
    }
}
