import React from 'react'
import ShipperResultPartsItem from '../presentational/input/ShipperResultPartsItem';
import Col from '../presentational/Col';
import Row from '../presentational/Row';
export default function ShipperResultParts({
    label = "false",
    value = "",
    ...props }) {
    return (
        <Row>
            <Col md={3} sm={6}>
                <ShipperResultPartsItem
                    label="total chargable weight"
                    value="30.5"
                />
            </Col>
            <Col md={3} sm={6}>
                <ShipperResultPartsItem
                    label="مجموع وزن ناخالص "
                    value="30.5"
                />
            </Col>
            <Col md={3} sm={6}>
                <ShipperResultPartsItem
                    label="total chargable weight"
                    value="30.5"
                />
            </Col>
            <Col md={3} sm={6}>
                <ShipperResultPartsItem
                    label="مجموع وزن ارزش کالا"
                    value="30.5ریال"
                />
            </Col>




        </Row>
    )
}
