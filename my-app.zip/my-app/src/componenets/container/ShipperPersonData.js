import React, { Component } from 'react'
import FormData from '../presentational/input/FormData';
import PersonDataView from '../container/PersonDataView';

export default class ShipperPersonData extends Component {
    render() {
        const { data } = this.props

        return (
            <div>
                <PersonDataView data={this.props.data} />
                <hr />
                <FormData
                    label="description"
                    value={data.notes}
                    labelClassName=""
                />
            </div>
        )
    }
}
