import React, { Component } from 'react'
// import FormData from '../presentational/input/FormData';
import FormData from '../presentational/input/FormData';

export default class ShipperNumbers extends Component {

    render() {
        const { data } = this.props
        return (
            <>
                <FormData
                    label="refrense number"
                    value=" 283.400ریال "
                    // labelClassName=" "
                    valueClassName="col-md-3"
                />
                <FormData
                    label="pickup number"
                    value="اعتباری"
                // labelClassName=" "
                // valueClassName="col-md-3"
                />
                <FormData
                    label="Tracking Code"
                    value="s7s854sd6"
                    // labelClassName=" "
                    valueClassName="col-md-3"
                />
                <FormData
                    label="payment refrence info"
                    value="تعداد ۶ عدد گوشی"
                    // labelClassName=" "
                    valueClassName="col-md-3"
                />

            </>
        )
    }
}
ShipperNumbers.defaultProps = {
    data: {
        totalAmount: 'totalAmount',
        paymentMethod: 'paymentMethod',
        chargeParty: 'chargeParty',
        paymentReferenceInfo: 'paymentReferenceInfo'
    }
}