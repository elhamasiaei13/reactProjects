import React from 'react';
import Button from '../presentational/button/Button';
import ButtonGroup from '../presentational/button/ButtonGroup';

const ShipmentActionBar = ({ ...props }) => {
    return (
        <ButtonGroup>
            <Button label="Print" type="info" />
            <Button label="Print Tags" type="info" />
            <Button label="Back" />
        </ButtonGroup>);

}
export default (ShipmentActionBar);
