import React, { Component } from 'react'
import FormInput from '../presentational/input/FormInput';
import Row from '../presentational/Row'
import Col from '../presentational/Col';
import Button from '../presentational/button/Button';
import { Redirect } from 'react-router-dom';
export default class LoginForm extends Component {
    constructor(props) {
        super(props);
        this.state = {
            redirect: false,
            username: 'dd',
            password: 'dd'
        }
        this.submit = this.submit.bind(this)
    }

    submit(e) {
        console.log("prop", this.props);
        e.preventDefault();
        localStorage.setItem('authentication', JSON.stringify(true))
        // this.setState((state, props) => { return { redirect:true }})
        this.setState({ redirect: true })
        this.props.setAuth()
    }

    render() {
        const { username, password, redirect } = this.state
        if (redirect) {
            return <Redirect to="/shipments" />
        }
        return (
            <Row>
                <Col md={8}>

                    <form onSubmit={this.submit} className="form-horizontal">
                        <FormInput
                            label="user name"
                            value={username}
                        />

                        <FormInput
                            label="password"
                            type="password"
                            value={password}
                        />
                        <Row>
                            <Col md={10} >
                            </Col>

                            <Col md={2} >
                                <div className="button-group">
                                    <Button label="submit" type="info" htmlType="submit" />
                                    <Button label="reset" type="info" />
                                </div>
                            </Col>
                        </Row>
                    </form>
                </Col>
            </Row>
        )
    }
}
