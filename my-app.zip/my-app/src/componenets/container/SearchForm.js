import React, { Component } from 'react'
import Form from '../presentational/form/Form'
import FormInput from '../presentational/input/FormInput'
import Select from '../presentational/input/Select'
import FormDatePicker from '../presentational/input/FormDatePicker'
import Button from '../presentational/button/Button';
import ButtonGroup from '../presentational/button/ButtonGroup';
export default class SearchForm extends Component {
    initialState = {
        waybillNumber: '',
        waybillNumberFrom: '',
        waybillNumberTo: '',
        issuingDateFrom: '1',
        issuingDateTo: '',
        paymentMethod: '',
        currentStates: '',
        deliveryDateFrom: '',
        deliveryDateTo: '',
        paymentMethods: '',
        consigneeCityCodes: '',
        currentShipmentState: '',
        consigneeCity: ''
    }

    constructor(props) {
        super(props);
        this.reset = this.reset.bind(this);
        this.state = this.initialState
    }

    onChange(event) {
        // console.log(event.target.name);
        const target = event.target;
        const value = target.value;
        const name = target.name;
        this.setState({
            [name]: value
        });
    }

    handleSubmit = (e) => {
        e.preventDefault()
        console.log(e.target);
        this.props.searcValue([{
            '#': '1', 'شماره بارنامه': '210130023054', 'وضعیت کنونی': 'DELIVERED', 'تایخ صدور': '1396-06-11 17:13'
            , 'نحوه ‍پرداخت': 'CREDIT', 'شهر گیرنده': 'IR-SHRZ'
        }])
    }

    reset = () => {
        console.log("reset");
        this.setState(() => this.initialState)

        // this.setState({
        //     waybillNumber: '',
        //     waybillNumberFrom: '',
        //     waybillNumberTo: '',
        //     issuingDateFrom: '',
        //     issuingDateTo: '',
        //     paymentMethod: '',
        //     currentStates: '',
        //     deliveryDateFrom: '',
        //     deliveryDateTo: '',
        //     paymentMethods: '',
        //     consigneeCityCodes: '',
        //     currentShipmentState: '',
        //     consigneeCity: ''
        // })
    }

    render() {
        const {
            waybillNumber,
            waybillNumberFrom,
            waybillNumberTo,
            issuingDateFrom,
            issuingDateTo,
            paymentMethod,
            currentStates,
            deliveryDateFrom,
            deliveryDateTo,
            paymentMethods,
            consigneeCityCodes,
            currentShipmentState,
            consigneeCity
        } = this.state

        return (
            <>
                <Form
                    onSubmit={this.handleSubmit}
                    formBody={<>
                        <div className="row">
                            <div className="col-md-6">
                                <FormInput
                                    label={"waybillNumber"}
                                    id="waybillNumber"
                                    type="text"
                                    name='waybillNumber'
                                    value={waybillNumber}
                                    onChange={(e) => this.onChange(e)}
                                />

                                <FormInput
                                    label={"waybillNumberFrom"}
                                    id="waybillNumberFrom"
                                    type="text"
                                    name='waybillNumberFrom'
                                    value={waybillNumberFrom}
                                    onChange={(e) => this.onChange(e)}
                                />

                                <FormInput
                                    label={"waybillNumberto"}
                                    id="waybillNumberto"
                                    type="text"
                                    name='waybillNumberTo'
                                    value={waybillNumberTo}
                                    onChange={(e) => this.onChange(e)}
                                />
                                <Select
                                    label={"paymentMethods"}
                                    id="title3"
                                    type="text"
                                    name='paymentMethods'
                                    options={["CASH", "CREDIT", "POS"]}
                                    value={paymentMethods}
                                    onChange={(e) => this.onChange(e)}
                                />
                            </div>
                            <div className="col-md-6">
                                <FormDatePicker
                                    label={"issuingDateFrom"}
                                    id="title1"
                                    type="date"
                                    name='issuingDateFrom'
                                    preSelected={issuingDateFrom}
                                    // value={issuingDateFrom}
                                    onChange={(unix, formatted) => {
                                        this.setState({ issuingDateFrom: formatted })
                                    }}
                                />
                                <FormDatePicker
                                    label={"issuingDateTo"}
                                    id="title2"
                                    type="date"
                                    name='issuingDateTo'
                                    value={issuingDateTo}
                                    onChange={(unix, formatted) => {
                                        this.setState({ toIssueDate: formatted })
                                    }} />
                                <FormDatePicker
                                    label={"deliveryDateFrom"}
                                    id="title1"
                                    type="date"
                                    name='deliveryDateFrom'
                                    value={deliveryDateFrom}
                                    onChange={(unix, formatted) => {
                                        this.setState({ deliveryDateFrom: formatted })
                                    }}
                                />
                                <FormDatePicker
                                    label={"deliveryDateTo"}
                                    id="title2"
                                    type="date"
                                    name='deliveryDateTo'
                                    value={deliveryDateTo}
                                    onChange={(unix, formatted) => {
                                        this.setState({ deliveryDateTo: formatted })
                                    }} />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-md-6">
                                <Select
                                    label={"currentStates"}
                                    type="text"
                                    name='currentStates'
                                    options={["DELIVERED", "ISSUED", "RETURNED", "VOIDED"]}
                                    value={currentStates}
                                    onChange={(e) => this.onChange(e)}
                                />
                            </div>
                            <div className="col-md-6">
                                <Select
                                    label={"consigneeCityCodes"}
                                    id="title1"
                                    type="text"
                                    name='consigneeCityCodes'
                                    options={["tehran", "shiraz"]}
                                    value={consigneeCityCodes}
                                    onChange={(e) => this.onChange(e)} />
                            </div>
                        </div>

                    </>}
                    formFooter={
                        <ButtonGroup>
                            <Button
                                type="info"
                                label={"search"}
                                className="btn btn-info waves-effect waves-light"
                                htmlType="submit">
                            </Button>
                            <Button
                                label={"reset"}
                                type="info"
                                className="btn btn-dark waves-effect waves-light"
                                onClick={this.reset}
                            >
                            </Button>
                        </ButtonGroup>

                    } />

            </>
        )
    }
}
