import React, { Component } from 'react'
// import FormData from '../presentational/input/FormData';
import FormData from '../presentational/input/FormData';
export default class ShipperPayment extends Component {

    render() {
        const { data } = this.props
        return (
            <>
                <FormData
                    label="totalAmount"
                    value={data.totalAmount}
                    // labelClassName=" "
                    // valueClassName="col-md-3"
                />

                <FormData
                    label="paymentMethod"
                    value={data.paymentMethod}
                    // labelClassName=" "
                    // valueClassName="col-md-3"
                />

                <FormData
                    label="chargeParty"
                    value={data.chargeParty}
                    // valueClassName="col-md-3"
                />
                <FormData
                    label="paymentReferenceInfo"
                    value={data.paymentReferenceInfo}
                    // valueClassName="col-md-3"
                />


            </>
        )
    }
}
ShipperPayment.defaultProps = {
    data: {
        totalAmount: 'totalAmount',
        paymentMethod: 'paymentMethod',
        chargeParty: 'chargeParty',
        paymentReferenceInfo: 'paymentReferenceInfo'
    }
}