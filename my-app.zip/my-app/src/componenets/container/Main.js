import React, { Component } from 'react';
import { Route, Redirect } from 'react-router-dom';
import Breadcrumb from '../presentational/breadcrumb/Breadcrumb';
import ContainerFluid from '../Layout/content/ContainerFluid';
import Shipper from './Shipper';
import ShipmentTracking from './ShipmentTracking';
import Row from '../presentational/Row';
import Col from '../presentational/Col';
import Routing from '../presentational/Routing';
import Wrapper from '../presentational/Wrapper';
import Button from '../presentational/button/Button';
import { breakStatement } from '@babel/types';
import ShipmentActionBar from './ShipmentActionBar';
import SearchNav from '../nav/SearchNav';
import LoginForm from './LoginForm';

export default class Content extends Component {

    render() {
        const { authentication } = this.props
        console.log(this.props);

        return (
            <>
                {authentication && <>

                    <AuthenticatedRoute
                        exact path={"/"}
                        component={() => {
                            return <>
                                <Breadcrumb
                                    title={"home"}
                                />
                                <ContainerFluid >
                                    WelCome
                                </ContainerFluid >
                            </>
                        }}
                        authentication={authentication}
                    />

                    <AuthenticatedRoute
                        path={"/ShipmentTracking"}
                        component={() => {
                            return <>
                                <Breadcrumb
                                    nav={<ShipmentActionBar />}
                                    title={<>
                                        <img src="../../assets/image/imgTest.jpg" alt="user" className="rounded-circle" width="40"
                                        />
                                        ShipmentTracking</>} />
                                <ContainerFluid >
                                    <ShipmentTracking />
                                </ContainerFluid >

                            </>
                        }}
                        authentication={authentication}
                    />

                    <AuthenticatedRoute
                        path={"/shipments"}
                        component={() => {
                            return (<>
                                <Breadcrumb title="shipments" />
                                <ContainerFluid >
                                    <Row>
                                        <Shipper />
                                    </Row>
                                </ContainerFluid >
                            </>)
                        }}
                        authentication={authentication}
                    />
                </>
                }
                {!authentication && <Route exact path="/login"
                    render={() => {
                        return (
                            <>
                                <ContainerFluid >
                                    salam
                                    <LoginForm />
                                </ContainerFluid >
                            </>
                        )
                    }} />}
            </>
        )
    }
}

const AuthenticatedRoute = ({ component: Component, authentication, ...rest }) => (
    <Route {...rest} render={props => (
        JSON.parse(localStorage.getItem("authentication")) ? (
            <Component {...props} />
        ) : (<>
            {console.log("props", props)}
            <Redirect to={{
                pathname: '/login',
                // state: { from: props }
            }} />
        </>)
    )} />
)
