import React, { Component } from 'react'
import { Link } from 'react-router-dom/cjs/react-router-dom.min';
import MenuItem from '../sider/MenuItem';

export default class Menu extends Component {
    render() {
        return (
            <>

                <Link to="/shipments">
                    <MenuItem
                        title={"shipments"}
                        icon={"mdi mdi-map"}
                    />
                </Link>
              
                <Link to="/ShipmentTracking">
                    <MenuItem
                        title={"ShipmentTracking"}
                    />
                </Link>
               
            </>
        )
    }
}
