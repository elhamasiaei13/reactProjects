

import React, { Component } from 'react'
import FormData from '../presentational/input/FormData';
import ViewData from '../presentational/input/ViewData';
import ViewLabel from '../presentational/input/ViewLabel';
// const ViewData=()=>{
// return(
//     <>
//     </>
// )
// }


export default class PersonDataView extends Component {
    render() {
        const { data } = this.props
        // const test={clientId:"ggg"}
        return (
            <>
                <ViewLabel
                    value="آقای مهندس علیرضا اسدی"
                />
                {(data.clientId || data.nationalId) &&
                    <div className="form-group row">
                        <ViewData
                            label="clientId"
                            value={data.clientId}
                        />

                        <ViewData
                            label="nationalId"
                            value={data.nationalId}
                        />
                    </div>
                }

                <ViewLabel
                    value={<><b> {data.city}</b> ({data.country} ,{data.province})</>}

                />
                <ViewLabel
                    value={data.address}
                />

                <FormData
                    label="phone"
                    value={data.phone}
                    labelClassName=""
                />
                <FormData
                    label="postalCode"
                    value={data.postalCode}
                    labelClassName=""
                />

            </>
        )
    }
}
