import React, { Component } from 'react';
import Table from '../presentational/table/Table';
import Card from '../presentational/card/Card';
import SearchForm from '../container/SearchForm';
import Breadcrumb from '../presentational/breadcrumb/Breadcrumb';
import Col from '../presentational/Col';
export default class Shipper extends Component {
    constructor(props) {
        super(props);
        this.state = {
            data: [
                {
                    '#': 1, "waybillNumber": '210130023054', '"Current Shipment State"': 'DELIVERED', 'Issuing Date To': '1396-06-11 17:13'
                    , "Payment Method": 'CREDIT', "Consignee City": 'IR-SHRZ'
                },
                {
                    '#': 1, "waybillNumber": '210130023054', '"Current Shipment State"': 'DELIVERED', 'Issuing Date To': '1396-06-11 17:13'
                    , "Payment Method": 'CREDIT', "Consignee City": 'IR-SHRZ'
                },
                {
                    '#': 1, "waybillNumber": '210130023054', '"Current Shipment State"': 'DELIVERED', 'Issuing Date To': '1396-06-11 17:13'
                    , "Payment Method": 'CREDIT', "Consignee City": 'IR-SHRZ'
                }

            ]
        }
    }

    searcValue = (value) => {
        this.setState({ data: value })
    }

    render() {
        const { data } = this.state;
        return (
            <Col md={12} >
                <Card cardTitle="search">
                    <SearchForm searcValue={this.searcValue} />
                    <Table
                        // tableClass="table table-striped"
                        theader={['#', "waybillNumber",
                            "issuingDate", "deliveryDate",
                            ,"shipper","shipperCity", "consignee",
                            "consigneeCity",  "paymentMethod",  "chargeParty", "currentState",
                            , "activity"]}
                        tbody={data}
                    />
                </Card>
            </Col>
        )
    }
}
