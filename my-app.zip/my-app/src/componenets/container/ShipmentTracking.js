import React, { Component } from 'react'
import Card from '../presentational/card/Card'
import CardBody from '../presentational/card/CardBody'
import Table from '../presentational/table/Table';
import { Route } from 'react-router-dom';
import Breadcrumb from '../presentational/breadcrumb/Breadcrumb';
import ContainerFluid from '../content/ContainerFluid';
import FormData from '../presentational/input/FormData';
import Shipper from './Shipper'
import ShipperResultParts from './ShipperResultParts'
import ShipperPayment from './ShipperPayment'
import ShipperNumbers from './ShipperNumbers'
import PersonDataView from './PersonDataView'
import CurrentRecordStatus from './CurrentRecordStatus'
import Tabs from '../presentational/tab/Tabs'
import TabPane from '../presentational/tab/TabPane'
import FormInput from '../presentational/input/FormInput';
import SearchInput from '../presentational/input/SearchInput';
import Row from '../presentational/Row';
import Col from '../presentational/Col';
import Button from '../presentational/button/Button';
import ShipperStatus from '../presentational/timeLine/ShipperStatus';
import ShipperPersonData from './ShipperPersonData'
export default class ShipmentTracking extends Component {
    constructor(props) {
        super(props);
        this.state = {
            data: '',
            shipper: {},
            consignee: {},
            parcels: {},
            paymentInfo:{},
            ShipperResultParts:{},
        }
    }

    render() {
        const {
            data,
            shipper,
            consignee,
            parcels,
            paymentInfo,
        } = this.state
        return (
            <>
                <Row>
                    <Col md={12} lg={6}>
                        <Card
                            cardTitle="shipper">
                            <ShipperPersonData
                                data={shipper} />
                        </Card>
                    </Col>
                    <Col md={12} lg={6}>
                        <Card
                            cardTitle="consignee"

                        >
                            <ShipperPersonData
                                data={consignee} />
                        </Card>

                    </Col>
                </Row >

                <Row>
                    <Col md={12}>
                        <Card cardTitle=
                            {<Row>
                                <Col md={8}>parcels </Col>
                                <Col sm={12} md={4} lg={4} ><SearchInput /></Col>
                            </Row>} >
                            <Table
                                theader={['partNumber', 'DIMs', 'grossWeight', 'content'
                                    , 'packageType', 'declaredValue']}
                                tbody={[parcels,{
                                    'partNumber': '66', 'DIMs': '', 'grossWeight': 'grossWeight', 'content': 'content'
                                    , 'packageType': 'packageType', 'declaredValue': 'declaredValue'
                                }]}
                            />
                            <ShipperResultParts data={"ShipperResultParts"} />

                        </Card>

                    </Col>
                </Row>

                <Row>
                    <Col lg={6} md={12} >

                        <Card cardTitle="payment" >
                            <ShipperPayment data={paymentInfo} />
                        </Card>
                    </Col>
                    <Col lg={6} md={12} >

                        <Card cardTitle="ShipperNumbers" >
                            <ShipperNumbers data={""} />
                        </Card>
                    </Col>

                </Row >

                <Row>
                    <Col lg={6} md={12} >
                        <Card
                            cardTitle="وضعیت فعلی سابقه"
                        >
                            <ShipperStatus data={""}/>
                        </Card>
                    </Col>
                    <Col md={12} lg={6} >
                    </Col>
                </Row >

            </>
        )
    }
}
