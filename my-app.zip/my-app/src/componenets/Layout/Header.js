import React from 'react';
import DropDown from '../nav/DropDown';
import SearchNav from '../nav/SearchNav'
const Header = () => {
    return (
        <header className="topbar"
            // test
            data-navbarbg="skin6"
        // test
        >
            <nav className="navbar top-navbar navbar-expand-md navbar-light">
                <div className="navbar-header"
                    // test
                    data-logobg="skin5"
                // test
                >
                    <span className="nav-toggler waves-effect waves-light d-block d-md-none" >
                        <i className="ti-close ti-menu"></i>
                    </span>
                    <div className="navbar-brand">
                        <span className="logo">
                    {/* if side bar toggle below tag should use */}
                            {/* <b className="logo-icon">
                                <img src="../../assets/image/imgTest.jpg" width="30" alt="homepage" className="dark-logo" />
                            </b> */}
                            {/* <span className="logo-text">
                                <img src="../../assets/image/imgTest.jpg" width="30" className="light-logo" alt="homepage" />
                                logo-text
                             </span> */}
                        </span>
                        {/* <span className="sidebartoggler d-none d-md-block" data-sidebartype="mini-sidebar">
                            <i className="mdi mdi-toggle-switch mdi-toggle-switch-off font-20"></i>
                        </span> */}
                    </div>
                </div>
                <div className="navbar-collapse collapse" id="navbarSupportedContent" data-navbarbg="skin6">
                    <SearchNav />
                    <DropDown />

                </div>
            </nav>
        </header>

    )
}
export default (Header);