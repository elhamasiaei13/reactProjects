

import React from 'react'
import Card from '../presentational/card/Card'
import Table from '../presentational/table/Table';
import { Route } from 'react-router-dom';
const ContainerFluid = ({ BreadcrumbTitle = "false", body = "salam", nav, ...props }) => {
    return (
        <div className="container-fluid">
            {props.children}
        </div>

    )
}
export default ContainerFluid;