import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import * as serviceWorker from './serviceWorker';
import { BrowserRouter } from 'react-router-dom';
import { IntlProvider, addLocaleData} from 'react-intl';
import fa from 'react-intl/locale-data/fa';
import en from 'react-intl/locale-data/en';
import persian from './language/persian';
import english from './language/english';

 addLocaleData([...fa, ...en]);

ReactDOM.render(
    <IntlProvider locale={'fa'}  messages={persian}>
        <BrowserRouter>
            <App />
        </BrowserRouter>
     </IntlProvider>

    ,
    document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
